
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My HTML Page</title>
    <link rel="stylesheet" type="text/css" title="Cool stylesheet" href="style.css">
  </head>
  <body>
    <div id="root">
      <form action="tester.php" method="POST">
        <input type="number" name ="stdnumber" /> <br />
        <input type="text" name ="fn" /> <br />
        <input type="text" name ="ln" /> <br />
        <input type="text" name ="course" /> <br />
        <input type="submit" />
      </form>

    </div>
    <script src="main.js" type="text/javascript"></script>
  </body>
</html>
