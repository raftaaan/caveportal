<?php
require_once $_SERVER['DOCUMENT_ROOT'].'/registrardev/resource/php/class/core/init.php';
if(isset($_POST['Purpose'])){
  $print = new verified($_POST['id'],$_POST['fail'],$_POST['Purpose']);
  $print->verifyFail();
  header('Location: verification.php');
}
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Registrar Portal</title>
  <link rel="stylesheet" type="text/css"  href="vendor/css/bootstrap.min.css">
  <link href="vendor/css/all.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css"  href="resource/css/styles.css">
  <link rel="stylesheet" type="text/css"  href="vendor/css/bootstrap-select.min.css">

</head>
<body>

        <nav class="navbar navbar-dark bg-white shadow-sm slide-in-left">
          <a class="navbar-brand" href="https://malolos.ceu.edu.ph/">
            <img src="resource/img/logo.jpg" height="70" class="d-inline-block align-top"
              alt="mdb logo"><h3 class="ib">
          </a>
             <a href="pending.php"><i class="fas fa-home ceucolor"></i></a>
             <a href="https:/www.facebook.com/theCEUofficial/"><i class="fab fa-facebook-f ceucolor"></i></a>
             <a href="https://www.instagram.com/ceuofficial/"><i class="fab fa-instagram ceucolor"></i></a>
             <a href="https://twitter.com/ceumalolos"><i class="fab fa-twitter ceucolor"></i></a>
        </nav>

        <div class="container mt-4 puff-in-center">
          <div class="row mt-5 justify-content-center shadow-sm">
            <div class="col-10  py-5 ">
              <form action="" method="POST">
                <h2>Candidate Failure Reason</h2>
                <sm>Please state the reason for candidate failure of verification.</sm><br /><br />
                <div class="form-group col-10">
                  <label for="studentN">Candidate Name</label>
                  <input type="text" class="form-control" id="fullnameC"  value="<?php echo $_GET['fail']; ?>" name="id" hidden>
                  <input type="text" class="form-control" id="fullnameC"  value="<?php echo $_GET['id']; ?>" name="fail" hidden>
                  <input type="text" class="form-control" id="fullnameC"  value="<?php echo $_GET['fname']; ?>" name="fullnameC" disabled>
                </div>
                <div class="form-group col-10">
                  <label for="Purpose" >Reason for Failure</label>
                      <select id="Purpose" name="Purpose" class="selectpicker form-control">
                        <option value="Transferred to Mendiola">Transferred to Mendiola OUR</option>
                        <option value="Transferred to Makati">Transferred to Makati OUR</option>
                        <option value="Incorrect data or record">Incorrect data/record given</option>
                        <option value="Data not found">Data not found</option>
                      </select>
                      <br />
                      <br />
                      <br />
                      <input type="submit" value="Submit Verification" class=" form-control btn btn-primary" />
                </div>
              </form>
            </div>
          </div>

        </div>

</body>
<footer id="sticky-footer" class="py-4 bg-dark text-white-50 fixed-bottom  slide-in-right">
  <div class="container text-center">
      <div class="row">
          <div class="col col-sm-5 text-left">
              <small>Copyright &copy;Centro Escolar University     Office of the Registrar 2019</small>
          </div>
          <div class="col text-right">
              <small>Created by: Reymart Bolasoc, Amelia Valencia , James Mangalile, Kenneth De Leon , Pamela Reyes , Ellen Mijares</small>
          </div>
      </div>
  </div>
</footer>
    <script src="vendor/js/jquery.js"></script>
    <script src="vendor/js/popper.js"></script>
    <script src="vendor/js/bootstrap.min.js"></script>
    <script src="vendor/js/bootstrap-select.min.js"></script>
</body>
</html>
