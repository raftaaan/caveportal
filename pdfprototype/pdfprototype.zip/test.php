<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>pirma boiz</title>
  <link rel="stylesheet" type="text/css" title="Cool stylesheet" href="style.css">
  <style>
  a{
    font-size: 64px;
  }
  </style>
</head>
<body>
<a href="view.php">View scholarship application file</a><br />
<a href="head.php">pirma head or dean</a><br />
<a href="registrar.php">pirma registrar</a><br />
<a href="vp.php">pirma vp acad</a><br />

</body>
</html>
